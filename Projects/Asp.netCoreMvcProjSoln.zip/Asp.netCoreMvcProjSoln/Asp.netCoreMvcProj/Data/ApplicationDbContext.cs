﻿using Asp.netCoreMvcProj.Models;
using Microsoft.EntityFrameworkCore;

namespace Asp.netCoreMvcProj.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }
        public DbSet<Subject> Subjects { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>()
                .HasOne(s => s.Subject)
                .WithMany(sub => sub.Students)   // Explicitly link back
                .HasForeignKey(s => s.SubjectId)
                .OnDelete(DeleteBehavior.SetNull); // Prevent cascade delete wiping students

            base.OnModelCreating(modelBuilder);
        }
    }
}
