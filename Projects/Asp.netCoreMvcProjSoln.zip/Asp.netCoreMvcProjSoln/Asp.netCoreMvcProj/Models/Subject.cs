﻿using System.ComponentModel.DataAnnotations;

namespace Asp.netCoreMvcProj.Models
{
    public class Subject
    {
        public int Id { get; set; }

        [Required, StringLength(50)]
        public string SubjectName { get; set; } = string.Empty;

        [Range(1, 365)]
        public int Duration { get; set; }

        public ICollection<Student> Students { get; set; } = new List<Student>();
    }
}
