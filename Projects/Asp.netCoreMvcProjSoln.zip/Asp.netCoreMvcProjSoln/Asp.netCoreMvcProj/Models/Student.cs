﻿
using System.ComponentModel.DataAnnotations;

namespace Asp.netCoreMvcProj.Models
{
    public class Student
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Range(5, 100)]
        public int? Age { get; set; }

        public int? SubjectId { get; set; }

        public Subject? Subject { get; set; }
    }
}
