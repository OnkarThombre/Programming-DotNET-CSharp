﻿using Asp.netCoreMvcProj.Data;
using Asp.netCoreMvcProj.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Asp.netCoreMvcProj.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDbContext _appDbContext;

        public StudentController(ApplicationDbContext dbcontext)
        {
            _appDbContext = dbcontext;
        }
        //public IActionResult Index()
        //{
        //    //var students = new List<Student>   //() paranthesis here is acceptable
        //    //{
        //    //    new Student{Id = 1 , Age = 23 , Name = "Onkar"},
        //    //    new Student{Id = 2 , Age = 50 , Name = "Akash"},

        //    //};

        //    var students = _appDbContext.Students;//.ToList(); // both works writint ToList() and without writing it
        //    return View(students);//students);
        //}

        public IActionResult Index()
        {
            var students = _appDbContext.Students
                            .Include(s => s.Subject)
                            .ToList();

            return View(students);
        }


        public IActionResult Create()
        {
            ViewBag.Subjectss = _appDbContext.Subjects.ToList();
            return View();
        }

        //[HttpPost]
        //public IActionResult Create(Student std)
        //{
        //    if(ModelState.IsValid)
        //    {
        //        _appDbContext.Students.Add(std);
        //        _appDbContext.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(std);
        //}

        [HttpPost]
        public async Task<IActionResult> Create(Student student)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Subjectss = _appDbContext.Subjects.ToList();
                return View(student);
            }

            await _appDbContext.Students.AddAsync(student); // ✅ Await here
            await _appDbContext.SaveChangesAsync();         // ✅ Persist changes
            return RedirectToAction("Index");
        }



        public IActionResult Edit(int id)
        {
            //var anystd = _appDbContext.Students.FirstOrDefault(x => x.Id == id);
            var anystudent = _appDbContext.Students.Find(id);
            if(anystudent == null)
            {
                return NotFound();  // notfound gives 404 page not found error
            }
            return View(anystudent);
        }

        [HttpPost]
        public IActionResult Edit(Student student)
        {
            if (!ModelState.IsValid)
            {
                return View(student);
            }

            _appDbContext.Students.Update(student);
            _appDbContext.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var foundStd = _appDbContext.Students.Find(id);
            if(foundStd == null)
            {
                return NotFound();
            }

            return View(foundStd);
        }

        [HttpPost]
        public IActionResult Delete(Student delstd)
        {
            var ftodelstd = _appDbContext.Students.Find(delstd.Id);
            if(ftodelstd == null)
            {
                return NotFound();
            }

            _appDbContext.Students.Remove(ftodelstd);
            _appDbContext.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}

