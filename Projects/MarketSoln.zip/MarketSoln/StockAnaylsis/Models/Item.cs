﻿namespace StockAnaylsis.Models
{
    
    public class Item
    {
        public int Id { get; set; }

        public string ItemName { get; set; }

        public double RemQuantity { get; set; }

        public double? Price { get; set; } 
    }
}
