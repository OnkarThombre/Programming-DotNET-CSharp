﻿using Microsoft.AspNetCore.Mvc;
using StockAnaylsis.Data;
using StockAnaylsis.Models;

namespace StockAnaylsis.Controllers
{
    public class ItemController : Controller
    {
        private readonly ApplicationDbContext _db;

        public ItemController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            var fetchedItems = _db.itemsTable.ToList();
            //var staticItems = new List<Item>()
            //{
            //    new Item {Id = 1 , ItemName = "Soyabean" , RemQuantity=50100.57 , Price=82.17},
            //    new Item {Id = 1 , ItemName = "Dal" , RemQuantity=7000.47 , Price=109.17},
            //    new Item {Id = 1 , ItemName = "Shengdana" , RemQuantity=3070.47 , Price=153.17},
            //};
            return View(fetchedItems);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Item item)
        {
            if(!ModelState.IsValid)
            {
                return View(item);
            }

            _db.itemsTable.Add(item);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            var foundItem = _db.itemsTable.Find(id);
            if(foundItem == null)
            {
                return NotFound();
            }

            return View(foundItem);
        }

        [HttpPost]
        public IActionResult Edit(Item item)
        {
            if(!ModelState.IsValid)
            {
                return NotFound();
            }

            //_db.itemsTable.Add(item);  it gives error because we added whole thing in db so same id so exception
            _db.itemsTable.Update(item);
            _db.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var itemToDel = _db.itemsTable.Find(id);
            if (itemToDel == null)
            {
                return NotFound();
            }
            return View(itemToDel);
        }

        [HttpPost , ActionName("Delete")]
        public IActionResult Deletefinal(int id)
        {
            var itemToDel = _db.itemsTable.Find(id);

            if(itemToDel == null)
            {
                return NotFound();
            }

            _db.itemsTable.Remove(itemToDel);
            _db.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
