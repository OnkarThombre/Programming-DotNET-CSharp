﻿using Microsoft.EntityFrameworkCore;
using StockAnaylsis.Models;

namespace StockAnaylsis.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
        { 
        
        }

        public DbSet<Item> itemsTable { get; set; }
    }
}

